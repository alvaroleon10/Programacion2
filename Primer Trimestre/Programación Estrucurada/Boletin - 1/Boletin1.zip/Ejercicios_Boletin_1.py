'EJERCICIO 1'
'''
print(7>=27 and not (7<=2))
print(24>5 and 10<=10 or 10==5)
print((10>=15 or 23==13) and not(8==8))
print(not(6/3>3) or 7>7)

print("----------------")

'EJERCICIO 2'

print(27%4 + 15/4)
print(37/4**2-2)
print(9*2/3*10*3)
print((7*3-4*4)**2/4*2)

print("----------------")

'EJERCICIO 3'

precio = 75

print(precio >= 60 and precio <= 420)

num = 7

print(num%2!=0)

saldo = 120
dineroSacar = 110

print(saldo>=0 and dineroSacar<= saldo and dineroSacar>0)

hora = 19
minutos = 40

print(hora>=00 and hora<=23 and minutos>=0 and minutos<=59)

estadoCivil = 'D'

print(estadoCivil=='S' or estadoCivil == 'C' or estadoCivil == 'V' or estadoCivil == 'D')


'''
'EJERCICIO 4'

cantidad = 250

print(cantidad < 0 or cantidad > 300)

edad = 20

print(edad<16 or edad>22)

respuesta = 'S'

print(respuesta != 'S' and respuesta != 'N')

numero = 21

print(numero%3!=0 or numero%7!=0)

